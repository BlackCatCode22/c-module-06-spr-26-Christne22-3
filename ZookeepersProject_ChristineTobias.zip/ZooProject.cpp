// Christine Tobias
// file last edited date: 04/18/26

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>

using namespace std;

// Trim whitespace
string trim(const string& s) {
    size_t first = s.find_first_not_of(" \t\n\r");
    if (first == string::npos) return "";
    size_t last = s.find_last_not_of(" \t\n\r");
    return s.substr(first, last - first + 1);
}

// Lowercase helper
string toLower(const string& s) {
    string r = s;
    for (size_t i = 0; i < r.size(); i++)
        r[i] = tolower(r[i]);
    return r;
}

// Animal struct (Java‑style fields)
struct Animal {
    string habitat;
    string uniqueID;
    string name;
    int age;
    string species;
    string sex;
    string birthDay;
    string color;
    int weight;
    string fromCity;
    string fromCountry;

    // NEW FIELD
    string arrivalDate;

    Animal(
        const string& h,
        const string& id,
        const string& n,
        int a,
        const string& sp,
        const string& sx,
        const string& bd,
        const string& c,
        int w,
        const string& fc,
        const string& fco
    ) {
        habitat = h;
        uniqueID = id;
        name = n;
        age = a;
        species = toLower(sp);
        sex = sx;
        birthDay = bd;
        color = c;
        weight = w;
        fromCity = fc;
        fromCountry = fco;
        arrivalDate = "unknown";   // will be set after construction
    }
};

int main() {

    vector<string> namesList;
    vector<Animal> zooInventory;
    map<string, int> speciesCounts;

    // -----------------------------
    // READ animalNames.txt (Java style)
    // -----------------------------
    {
        ifstream nameReader("animalNames.txt");
        if (!nameReader) {
            cout << "Error reading animalNames.txt" << endl;
            return 1;
        }

        string line;
        while (getline(nameReader, line)) {
            line = trim(line);
            if (line.empty()) continue;
            if (line.find("Names") != string::npos) continue;

            stringstream ss(line);
            string name;
            while (getline(ss, name, ',')) {
                name = trim(name);
                if (!name.empty())
                    namesList.push_back(name);
            }
        }
    }

    // -----------------------------
    // READ arrivingAnimals.txt
    // -----------------------------
    {
        ifstream animalReader("arrivingAnimals.txt");
        if (!animalReader) {
            cout << "Error reading arrivingAnimals.txt" << endl;
            return 1;
        }

        string line;
        int nameIndex = 0;
        map<string, int> idCounters;

        while (getline(animalReader, line)) {
            line = trim(line);
            if (line.empty()) continue;

            // Split by commas
            vector<string> parts;
            {
                string part;
                stringstream ss(line);
                while (getline(ss, part, ',')) {
                    parts.push_back(trim(part));
                }
            }
            if (parts.size() < 6) continue;

            // First part: "4 year old female hyena"
            vector<string> tokens;
            {
                string tok;
                stringstream ss(parts[0]);
                while (ss >> tok) tokens.push_back(tok);
            }
            if (tokens.size() < 5) continue;

            int age = atoi(tokens[0].c_str());

            string sex = tokens[3];
            if (sex.find("female") != string::npos) sex = "female";
            else if (sex.find("male") != string::npos) sex = "male";
            else sex = "unknown";

            string species = toLower(tokens[4]);

            // BirthDay (Java rules)
            string birthDay = parts[1];
            if (birthDay.find("winter") != string::npos) birthDay = "2018-12-21";
            else if (birthDay.find("spring") != string::npos) birthDay = "2018-03-21";
            else if (birthDay.find("summer") != string::npos) birthDay = "2018-06-21";
            else if (birthDay.find("fall") != string::npos) birthDay = "2018-09-21";
            else birthDay = "unknown";

            // Color
            string color = parts[2];
            size_t pos = color.find("color");
            if (pos != string::npos) color.erase(pos, 5);
            color = trim(color);

            // Weight
            string wStr = parts[3];
            pos = wStr.find("pounds");
            if (pos != string::npos) wStr.erase(pos, 6);
            wStr = trim(wStr);
            int weight = atoi(wStr.c_str());

            // From city
            string fromCity = parts[4];
            pos = fromCity.find("from");
            if (pos != string::npos) fromCity.erase(pos, 4);
            fromCity = trim(fromCity);

            string fromCountry = parts[5];

            // Assigned name
            string assignedName = "Unknown";
            if (!namesList.empty()) {
                assignedName = namesList[nameIndex % namesList.size()];
                nameIndex++;
            }

            // Unique ID (Java style)
            idCounters[species]++;
            int nextID = idCounters[species];

            stringstream idStream;
            idStream << species.substr(0, 2) << "0" << nextID;
            string uniqueID = idStream.str();

            // Habitat (match Java)
            string habitat;
            if (species == "hyena") habitat = "Hyena Habitat";
            else if (species == "lion") habitat = "Lion Habitat ";
            else if (species == "tiger") habitat = "Tiger Habitat";
            else if (species == "bear") habitat = "Bear Habitat ";
            else continue;

            // Add to inventory
            zooInventory.push_back(
                Animal(habitat, uniqueID, assignedName, age, species, sex,
                       birthDay, color, weight, fromCity, fromCountry)
            );

            // -----------------------------
            // Compute arrivalDate = birthDay + 1 year
            // -----------------------------
            Animal &a = zooInventory.back();

            if (a.birthDay != "unknown" && a.birthDay.size() == 10) {
                string yearStr = a.birthDay.substr(0, 4);
                int year = atoi(yearStr.c_str());
                year += 1;

                stringstream ad;
                ad << year << a.birthDay.substr(4);  // keep "-MM-DD"
                a.arrivalDate = ad.str();
            } else {
                a.arrivalDate = "2019-12-31";
            }
        }
    }

    // -----------------------------
    // COUNT SPECIES TOTALS
    // -----------------------------
    for (size_t i = 0; i < zooInventory.size(); i++) {
        speciesCounts[zooInventory[i].species]++;
    }

    // -----------------------------
    // WRITE important.ZooPopulation.txt
    // -----------------------------
    ofstream writer("important.ZooPopulation.txt");
    if (!writer) {
        cout << "Error writing important.ZooPopulation.txt" << endl;
        return 1;
    }

    writer << "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
    writer << "         ZOO REPORT         \n";
    writer << "~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n";

    writer << "\n~~~ Animal Inventory ~~~\n\n";

    for (size_t i = 0; i < zooInventory.size(); i++) {
        Animal& a = zooInventory[i];
        writer << a.habitat << " | "
               << a.uniqueID << " | "
               << a.name << " | "
               << a.age << " | "
               << a.species << " | "
               << a.sex << " | "
               << a.birthDay << " | "
               << a.color << " | "
               << a.weight << " lbs | "
               << a.fromCity << ", "
               << a.fromCountry << " | "
               << a.arrivalDate << "\n";
    }

    writer << "\n~~~ Species Totals ~~~\n\n";

    for (map<string,int>::iterator it = speciesCounts.begin();
         it != speciesCounts.end(); ++it)
    {
        writer << it->first << ": " << it->second << "\n";
    }

    writer.close();

    cout << "Process Complete. Check 'important.ZooPopulation.txt' for the Animal Inventory Report!" << endl;
    return 0;
}